<?php

class Database
{
    // We haven't implemented database based session
    // But when we do, do NOT forget to close() session.

    function close()
    {
        return 0;
    }
}
